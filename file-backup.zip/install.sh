#!/bin/bash
output=$(file-backup --version)
echo "Previous version : $output"
systemctl stop file-backup
rm -rf /usr/bin/file-backup
cp file-backup /usr/bin/
systemctl restart file-backup
output=$(file-backup --version)
echo "Current version : $output"
